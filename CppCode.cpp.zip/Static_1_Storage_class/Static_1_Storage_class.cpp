// Static_1_Storage_class.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*
Static local variables:
    Visibilty : Visible(accessible) only inside the code block where they have been defined
    Lifetime  : Througout the execution of the program
                It is created when the program execution begins and is destroyed only
                when the program exectuion gets over
    Linkage   : Internal
*/

#include <iostream>

void bar() {
    static int counter{ 30 };
    std::cout << "bar::counter : " << counter << std::endl;
    ++counter;
}
void multiply(int value) {
    // int counter{1}; //automatic local variable
    static int counter{ 1 }; // static local variable
    int result = value * counter;
    std::cout << value << " * " << counter << " = " << result << std::endl;
    ++counter;
    return;
}

int main()
{
    multiply(4);
    multiply(4);
    bar();
    multiply(4);
    bar();
    multiply(4);
    //std::cout << counter;
    return 0;
}
