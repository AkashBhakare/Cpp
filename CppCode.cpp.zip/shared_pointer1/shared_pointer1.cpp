// shared_pointer1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include <memory>
using namespace std;
using std::string;
using::std::shared_ptr;
using std::cout;
using std::endl;
using std::make_shared;

void share_ptr_creation() {

	//Constructor taking a pointer as single argument
	shared_ptr<string> pRaj(new string("raj"));
	
	cout << "pRaj refers to : " << *pRaj << endl;

	shared_ptr<string> pJitu{ new string("jitu") };

	cout << "pJitu refers to : " << *pJitu << endl;

	//You can also use the convenience function make_shared() here:
	// Faster and safer
	shared_ptr<string> pNita = make_shared<string>("nita");

	//sharedptr<string> pNita = new string("nita");//ERROR

	// You can declare the shared pointer first and assign a new pointer
	// later on. you have to use reset() instead:
	shared_ptr<string> pNico4;
	//You can't use the assignment operator
	//pNico4 = new string("nico"); //ERROR: no assignment for ordinary pointer
	pNico4.reset(new string("nico")); //ok
   
	shared_ptr<string> pPrem{ new string("prem") }; //ok

	shared_ptr<string> pBjarne{ new string("Bjarne") };
	cout << "pBjarne refers to : " << "pBjarne" << endl;

	pBjarne.reset(new string("Stroustroup"));
	cout << "pBjarne refers to : " << *pBjarne << endl;

}
int main()
{
	share_ptr_creation();

	//Two shared pointers representing two persion by their name using the
	//Constructor taking a pointer as single argument
	shared_ptr<string> pRaj(new string("raj"));
	shared_ptr<string> pJitu(new string("jitu"));

	cout << "pRaj refers to : " << *pRaj << endl;
	cout << "pJitu refers to : " << *pJitu << endl;

	//capitlize persion names
	(*pRaj)[0] = 's';
	pJitu->replace(0, 1, "j");

	//put them multiple times in a container
	vector<shared_ptr <string >> whoMadeCoffee;
	whoMadeCoffee.push_back(pJitu);
	whoMadeCoffee.push_back(pJitu);
	whoMadeCoffee.push_back(pRaj);
	whoMadeCoffee.push_back(pJitu);
	whoMadeCoffee.push_back(pRaj);


	// print all elements
	for (auto ptr : whoMadeCoffee) {
		cout << *ptr << " ";
	}
	cout << endl;

	// Overwrite a name again
	*pRaj = "Rajesh";

	//print all elments again
	for (auto ptr : whoMadeCoffee) {
		cout << *ptr << " ";
	}
	cout << endl;

	// use_count() yield the current number of owners an object
	// refered to by shared pointers has.
	//cout << "use_count : " << whoMadeCoofee[0].use_count() << endl;
	/*
	* At the end of the program, when the last owner of a string
	* ggets destoryed, the shared pointer calls delete for the objects
	* it refers to
	*/
 
}