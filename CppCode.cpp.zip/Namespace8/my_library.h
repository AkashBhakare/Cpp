#pragma once
#include <iostream>
namespace my_library {
	namespace v1 {
		void doit() {
			std::cout << "Doing it in traditional way!\n";

		}
	}
	namespace v2 {
		void doit() {
			std::cout << "Doing it in New way!\n";

		}
	}
	inline namespace v3 {
		void doit() {
			std::cout << "Doing it in Latest way!\n";

		}
	}
}