// iterationFor.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*
for (Initialize_counter; conditional_test; reevaluation_parameter){
	Statements;
	statements;
}

*/

#include <iostream>

///*
//* Print integers in the range of 1..10 in ascending order
//*/
//int main()
//{
//	constexpr int LIMIT{ 10 };
//
//    int icounter{ 1 };           //initialize counter
//    while (icounter <= LIMIT) {  //conditional test
//	std::cout << "Value = " <<  icounter << std::endl;
//     ++icounter;              //re-evaluate the loop control variable
//	}
//	std::cout << "Last Value after the loop : " << icounter << std::endl;
//		/*int icounter{ };
//	for ( icounter= 1 ; icounter <= LIMIT; ++icounter) 
//			std::cout << "Value = " << icounter << std::endl;
//	}
//	std::cout << "Last Value after the loop : " << icounter << std::endl;*/
//	
//	for (int icounter{ 1 }; icounter <= LIMIT; ++icounter) {
//		std::cout << "Value = " << icounter << std::endl;
//
//			}
//	    std::cout << "Last Value after the loop : " << icounter << std::endl;
//	    return 0;
//
//}




/*
* Print integers in the range of 1..10 in descending order
*/
//int main() {
//	constexpr int UPPER_LIMIT{ 10 };
//	constexpr int LOWER_LIMIT{ 1 };
//	std::cout << "Integers in the range of 1 to 10 in descending order:" << std::endl;
//	for (int icounter{ UPPER_LIMIT }; icounter >= LOWER_LIMIT; --icounter) {
//		std::cout << "Value = " << icounter << std::endl;
//	}
//	return 0;
//}

//int main() {
//constexpr int UPPER_LIMIT{ 10 };
//constexpr int LOWER_LIMIT{ 1 };
//std::cout << "Integers in the range of 1 to 10 in descending order:" << std::endl;
//for (int icounter{ UPPER_LIMIT }; icounter >= LOWER_LIMIT; --icounter) {
//	std::cout << "Value = " << icounter << std::endl;
//}
//return 0;
//}

/*
* Print all odd integers in the range of 1 to n in ascending order
*/

//int main() {
//	int limit{};
//	std::cout << "Please enter a integer : ";
//	std::cin >> limit;
//	std::cout << "All odd integers in the range of 1 to " << limit << " are:" << std::endl;
//	for (int odd{ 1 }; odd <= limit; odd+=2) {
//		std::cout << odd << std::endl;
//	}
//	return 0;
//}

/*
* Print all odd integers in the range of 1 to n in descending order
*/

//int main() {
//	int inum{};
//	std::cout << "Please enter a integer : ";
//	std::cin >> inum;
//	std::cout << "All odd integers in the range of " << inum << "to 1 are:" << std::endl;
//	//inum = (inum % 2 == 0) ? (inum - 1) : inum;
//	if (inum % 2 == 0) {
//		inum = inum - 1;
//	}
//
//	/*Initialize counter of for loop may not have any expression*/
//	for (; inum >= 1; inum -= 2) {
//		std::cout << inum << std::endl;
//	}
//	return 0;
//}

//int main() {
//		int inum{};
//		std::cout << "Please enter a integer : ";
//		std::cin >> inum;
//		std::cout << "All odd integers in the range of " << inum << "to 1 are:" << std::endl;
//		//inum = (inum % 2 == 0) ? (inum - 1) : inum;
//		if (inum % 2 == 0) {
//			inum = inum - 1;
//		}
//	
//		/*Initialize counter of for loop may not have any expression
//		* Reevaluation parameter also may not have eny expression
//		*/
//		for (  ; inum >= 1;  ) {
//			std::cout << inum << std::endl;
//			inum -= 2;
//		}
//		return 0;
//	}

//int main() {
//	int inum{};
//	std::cout << "Please enter a integer : ";
//	std::cin >> inum;
//	std::cout << "All odd integers in the range of " << inum << "to 1 are:" << std::endl;
//	//inum = (inum % 2 == 0) ? (inum - 1) : inum;
//	if (inum % 2 == 0) {
//		inum = inum - 1;
//	}
//
//	/*Initialize counter of for loop may not have any expression
//	* Reevaluation parameter also may not have eny expression
//	* Conditional test is optional
//	*/
//	for (; ; ) { //infinite loop
//		std::cout << inum << std::endl;
//		inum -= 2;
//		if (inum < 1) {
//			break;
//		}
//	}
//	return 0;
//}


//int main() {
//	int inum{};
//	for (inum = 1; inum <= 5; inum++);
//	{
//		std::cout << inum << std::endl;
//	}
//
//	return 0;
//}


/*
Accept an integer n, and print all even numbers less than n
*/
//using namespace std;
//int main() {
//
//    int i{ 1 };
//
//    for (i = 1; i <= 20; i++) {
//        if (i % 2 == 0) {
//
//            cout << i << " ";
//        }
//
//    }
//    return 0;
//}


//using namespace std;
//int main(){
//    int i{};
//    int N{};
//    std::cout << "Please enter a integer : ";
//    std::cin >> i;
//    std::cout << "All even integers in the range of " << i << "to 1 are:" << std::endl;
//
//    for (i = 1; i <= 20; i++){
//
//        if (i % 2 == 0) {
//
//            cout << i << " \n ";
//        }
//
//    }
//    return 0;
//}
 
/*
accept an integer n, and print first n even numbers
*/
using namespace std;
int main() {
    int i{};
    int N{};
    int even{ 20 };
    cout << "Enter the value of N : ";
    cin >> N;

    cout << "FIRST even numbers are...\n";
    for (i = 1; i <= 20; i++) {

        if (i % 2 == 0) {

            cout << i << " \n ";
        }
    }
    return 0;
}
