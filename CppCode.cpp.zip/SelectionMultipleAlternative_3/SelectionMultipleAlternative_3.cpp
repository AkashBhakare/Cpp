// SelectionMultipleAlternative_3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

/*
Accept an alphabet and check whether its vowel or consonant
*/
#include <iostream>
#include <cctype>
#include <iomanip>
using std::cout;
using std::cin;
using std::endl;

//int main()
//{
//	char alphabet;
//	cout << "Please enter an alphabet :";
//	cin >> alphabet;
//	//cout << "is Alphabet ? " << std::boolalpha << ( isalpha(alphabet) ? true : false);
//	if (isalpha(alphabet)) {
//		if (alphabet == 'a' or alphabet == 'A') {
//			cout << "'" << alphabet << "' is a vowel" << endl;
//		}
//		else if (alphabet == 'e' or alphabet == 'E') {
//			cout << "'" << alphabet << "' is a vowel" << endl;
//		}
//		else if (alphabet == 'i' or alphabet == 'I') {
//			cout << "'" << alphabet << "' is a vowel" << endl;
//		}
//		else if (alphabet == 'o' or alphabet == 'O') {
//			cout << "'" << alphabet << "' is a vowel" << endl;
//		}
//		else if (alphabet == 'u' or alphabet == 'U') {
//			cout << "'" << alphabet << "' is a vowel" << endl;
//		}
//		else {
//			cout << "'" << alphabet << "' is a Consonant" << endl;
//		}
//	}
//	else {
//		cout << "'" << alphabet << "' is NOT a alphabet" << endl;
//	}
//	return 0;
//   
//}


int main()
{
	char alphabet;
	cout << "Please enter an alphabet :";
	cin >> alphabet;
	//cout << "is Alphabet ? " << std::boolalpha << ( isalpha(alphabet) ? true : false);
	if (char upperAlpha = toupper(alphabet); isalpha(upperAlpha)) {
		if (upperAlpha == 'A') {
			cout << "'" << alphabet << "' is a vowel" << endl;
		}
		else if (upperAlpha == 'E') {
			cout << "'" << alphabet << "' is a vowel" << endl;
		}
		else if (upperAlpha == 'I') {
			cout << "'" << alphabet << "' is a vowel" << endl;
		}
		else if (upperAlpha == 'O') {
			cout << "'" << alphabet << "' is a vowel" << endl;
		}
		else if (upperAlpha == 'U') {
			cout << "'" << alphabet << "' is a vowel" << endl;
		}
		else {
			cout << "'" << alphabet << "' is a Consonant" << endl;
		}
	}
	else {
		cout << "'" << alphabet << "' is NOT a alphabet" << endl;
	}

	return 0;

}