#include "Date.h"
#include <iostream>
#include <sstream>
#include <stdexcept>
namespace my_lib {
    /*Default : no-args constructor*/
    //Date::Date(void)
    //{
    //    day = 19;
    //    month = Month::aug;
    //    year = 2021;
    //}

    Date::Date(int d)
    {
        day = d;
        //month = Month::aug;
        //year = 2021;
    }

    Date::Date(int d, Month m, int y)
    {
        //do input validation
        if (is_date_valid(d, m, y)) {
            day = d;
            month = m;
            year = y;
        }
        else {
            throw std::invalid_argument("The date set is invalid!");
        }
    }

    bool Date::is_date_valid(int d, Month m, int y)
    {
        if (!(d >= 1 and d <= 30))
            return false;

        if (!(y >= 1947 and y < 2050))
            return false;

        return true;
    }


    std::string Date::getDate()
    {
        std::ostringstream output;
        output << "Date [" << day << ", " << static_cast<int>(month) << ", " << year << " ]\n";
        return output.str();
    }

    Date Date::add_days(int number_of_days)
    {
        constexpr int max_days_in_month{ 30 };
        constexpr int max_months{ 12 };

        int m{ static_cast<int>(month) };
        int y{ year };
        int d{ day + number_of_days };

        if (d > max_days_in_month) {
            m = m + (d / max_days_in_month);
            d = d % max_days_in_month;
        }

        if (m > max_months) {
            y = y + (m / max_months);
            m = m % max_months;
        }
        my_lib::Date new_date{ d, Month(m), y };
        return new_date;
    }
}