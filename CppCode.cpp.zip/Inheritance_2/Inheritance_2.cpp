// Inheritance_2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "Student.h"
#include  "GraduateStudent.h"


int main()
{
    try {
        Student s("Rajan", 14);
        s.print_details();

        GraduateStudent gs("Vedant", 15, "Thermo");
        gs.print_details();
    }
    catch (std::invalid_argument& ivr) {
        std::cerr << ivr.what();
    }
}