#include <iostream>
#include <string>
#include "Student.h"

bool Student::is_roll_number_valid(int _roll)
{
	constexpr int min_roll_number{ 1 };
	constexpr int max_roll_number{ 100 };
	return _roll >= min_roll_number and _roll <= max_roll_number;
}

bool Student::is_name_valid(std::string name)
{
	if (name.empty())
		return false;
	return true;
}

Student::Student(std::string _name, int _roll)
{
	if (is_name_valid(_name)) {
		name = _name;
	}
	else {
		throw std::invalid_argument("Invalid name !");
	}

	if (is_roll_number_valid(_roll)) {
		roll_no = _roll;
	}
	else {
		throw std::invalid_argument("Invalid Roll number");
	}

}

void Student::print_details()
{
	std::cout << "Name : " << name << "\tRoll No : " << roll_no << "\n";
}