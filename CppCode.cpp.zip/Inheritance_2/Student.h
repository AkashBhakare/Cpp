#include <string>

class Student {
private:
    std::string name;
    int  roll_no;
    bool is_roll_number_valid(int roll_number);
    bool is_name_valid(std::string name);
public:
    /*
    * Construct a Student class object
    * Args
    * _name : name of the Student
    * _roll : roll Number of the Student
    */
    Student(std::string _name, int _roll);

    /*
    * Destructor for Student
    */
    ~Student() = default;
    /*
    * Prints the student details
    */
    void print_details();
};