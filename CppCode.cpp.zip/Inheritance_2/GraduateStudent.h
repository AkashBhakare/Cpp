#pragma once
#include <string>
#include "Student.h"

class GraduateStudent :public Student
{
private:
	std::string specialization;
public:
	/*
	* Constructs Graduate Student object
	* Args:
	* _name : Name of the Student
	* _roll : Roll Number of the student
	* _specialization : The Subject choosen by Student for Specialization
	*/
	GraduateStudent(std::string _name, int _roll, std::string specialization);

	/*destructor for Graduate Student*/
	~GraduateStudent() = default;
	/*Prints the details of Graduate Student*/
	void print_details();
};
