#include "GraduateStudent.h"
#include <iostream>
GraduateStudent::GraduateStudent(std::string _name, int _roll, std::string _specialization) :Student(_name, _roll)
{
	/*name = _name;
	roll = _roll;*/
	specialization = _specialization;
}

void GraduateStudent::print_details()
{
	Student::print_details();
	std::cout << "Specialization : " << specialization << "\n";
}