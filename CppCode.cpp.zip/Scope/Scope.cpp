// Scope.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <thread>

//Global variable
const int MAX_AGE = 60;

void foo();
void bar();
void baz();

int main()
{
    int min_age{ 18 };
    std::cout << "MAX_AGE (main) :" << MAX_AGE << std::endl;
    std::cout << "min_age (main) :" << min_age << std::endl;
    foo();
    bar();
    baz();
    std::this_thread::sleep_for(std::chrono::seconds(5));
    return 0;
}

void foo() {
    //Allowed : Global scope
    std::cout << "MAX_AGE (foo)  :" << MAX_AGE << std::endl;

    //Not allowed : Local to function main
    //std::cout << "min_age (foo) :" << min_age << std::endl;
}


void bar() {
    int MAX_AGE{ 65 }; //local to function bar
    // Local variable is given preference over global varaible
    std::cout << "MAX_AGE (bar)  :" << MAX_AGE << std::endl;
    //Scope resolution operator ::GLOBAL_VARIABLE
    std::cout << "MAX_AGE (bar)  :" << ::MAX_AGE << std::endl;

}

//hiding
void baz() {
    int a{ 10 };
    std::cout << "a (baz)  :" << a << std::endl;
    {
        std::cout << "a (baz::unnamed code block)  :" << a << std::endl;
        char a{ 'W' }; //hides previous a
        std::cout << "a (baz::unnamed code block)  :" << a << std::endl;
        //scope limited to unnamed code block
        float b{ 2.3f };
        std::cout << "b (baz::unnamed code block)  :" << b << std::endl;

    }

    // std::cout << "b (baz::unnamed code block)  :" << b << std::endl;

    std::cout << "a (baz)  :" << a << std::endl;
    return;
}