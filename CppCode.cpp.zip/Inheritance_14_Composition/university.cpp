#include "university.h"
#include <sstream>
#include <memory>
#include <utility>
#include <algorithm>
#include "department.h"


mylib::University::University(std::string name, size_t yoe, Department&& dept)
{
	this->name = name;
	this->yoe = yoe;
	departments.emplace_back(std::make_unique<Department>(std::move(dept)));
}

std::string mylib::University::get_univ_info() {
	std::ostringstream info{};
	info << "Name : " << name << '\n';
	info << "Year of the Establishment : " << yoe << '\n';
	info << "Details of Departments : \n";

	for (size_t i{ 0 }; i < departments.size(); ++i) {
		info << "\t" << department[i]->get_dept_info();
	}
	return info.str();
}