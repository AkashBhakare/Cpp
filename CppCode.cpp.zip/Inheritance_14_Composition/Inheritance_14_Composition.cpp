// Inheritance_14_Composition.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "university.h"
#include "department.h"
#include <string>
#include <utility>
using namespace std::literals;
int main()
{
	{
		mylib::University u1("UOP"s, "Sarthk", 1956u, {"Computer","Akash",20});
		std::cout << u1.get_univ_info();
		std::cout << '\n';
		u1.add_departments("Physic"s, "Tejas", 15);
		std::cout << u1.get_univ_info();
	}
	std::cout << "done\n";
	return 0;
}

