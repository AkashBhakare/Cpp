// SelectoinsingleAlternativel.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//Guess the magic number

#include <iostream>
#include <thread>
#include <chrono>
int main()
{
    /*constexpr int MAGIC_NUMBER{ 56 };
    std::cout << "Guess the magic integer :";
    int my_guess{};
    std::cin >> my_guess;
    if (my_guess == MAGIC_NUMBER) {
        std::cout << "Yeah ! you got it right!!" << std::endl;
    }
    std::cout << "Bye Bye!\n";*/


    {
        constexpr int MAGIC_NUMBER{ 56 };
        std::cout << "Guess the magic integer :";
        int my_guess{};
        std::cin >> my_guess;
        if (my_guess == MAGIC_NUMBER) {
            std::cout << "Yeah ! you got it right!!" << std::endl;
            std::cout << "Bye Bye!\n";

        }

    }

    std::this_thread::sleep_for(std::chrono::seconds(10));
    return 0;
}