#pragma once
namespace my_lib {
	enum class Month : std::int8_t { jan = 1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };

	struct Date
	{
		int day;
		Month month;
		int year;
		/*Initialize the date instance to 19/8/2021*/
		void init(void);
		/*Initialize the date instance to given date*/
		void init(int day, Month mon, int year);
		/*Returns true if the date is valid otherwise returns false*/
		bool is_date_valid(int day, Month mon, int year);
		/*Prints the date (day,month,year) foramt*/
		void printDate();
		/*Takes integer as a argument.
		add argument as number of days
		Returns the new date*/
		Date add_days(int number_of_days);
	};

}