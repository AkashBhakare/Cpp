// SelectionSingleAlternative_4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
//Guess the magic Number

#include <iostream>
#include <thread>
#include <chrono>
#include <iomanip>
int main()
{
    /*{
        constexpr int MAGIC_NUMBER{ 56 };
        std::cout << "Guess the magic integer :";
        int my_guess{};
        std::cin >> my_guess;
        if (my_guess == MAGIC_NUMBER) {
            std::cout << "Yeah ! you got it right!!" << std::endl;
        }
        std::cout << "Bye Bye!\n";
    }*/

    {
        constexpr int MAGIC_NUMBER{ 56 };
        std::cout << "Guess the magic integer :";
        int my_guess{};
        std::cin >> my_guess;
        if (my_guess == MAGIC_NUMBER) {
            std::cout << "Yeah ! you got it right!!" << std::endl;
            std::cout << "You are a winner!" << std::endl;
        }
        std::cout << "Bye Bye!\n";
    }


    /* {
         constexpr int MAGIC_NUMBER{ 56 };
         std::cout << "Guess the magic integer :";
         int my_guess{};
         std::cin >> my_guess;
         if (my_guess == MAGIC_NUMBER)
             std::cout << "Yeah ! you got it right!!" << std::endl;
         std::cout << "Bye Bye!\n";
     }*/

     /*
     * Accept total sales of a salesman and calculate the commission to be paid
     * Commission is 5% of the total sales
     * Commission is paid only if the total sales >= Rs 100000
     */
     /*{
         constexpr unsigned SALES_TARGET{ 1'00'000 };
         constexpr double COMMISSION_RATE{ 0.05 };
         double commission{};
         unsigned total_sales{};
         std::cout << "Please enter total Sales in Rs:";
         std::cin >> total_sales;
         if (total_sales >= SALES_TARGET) {
             commission = total_sales * COMMISSION_RATE;
         }
         std::cout << "The Commission payable is Rs:"
             << std::setprecision(2) << std::fixed
             << commission << std::endl;
     }*/

    std::this_thread::sleep_for(std::chrono::seconds(4));
    return 0;
}