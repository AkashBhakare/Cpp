// SelectionDualAlternative_1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <thread>
#include <chrono>
#include <iomanip>
#include <cmath>
int main()
{

	/*{
		constexpr int MAGIC_NUMBER{ 56 };
		std::cout << "Guess the magic integer :";
		int my_guess{};
		std::cin >> my_guess;
		if (my_guess == MAGIC_NUMBER) {
			std::cout << "Yeah ! you got it right!!" << std::endl;
			std::cout << "You are a winner!" << std::endl;
		}
		else {
			std::cout << "Sorry! You got it wrong!!" << std::endl;
			std::cout << "Hard Luck! Try again later!" << std::endl;
		}
		std::cout << "Bye Bye!\n";
	}*/

	/*
	* Accept total sales of a salesman and calculate the commission to be paid
	* Commission of 5% of the total sales is paid if the
	  total sales >= Rs 100000
	  Commission of 1% of the total sales is paid if the
	  total sales < Rs 100000
	*/
	/*  {
		  constexpr unsigned SALES_TARGET{ 1'00'000 };
		  constexpr double MAX_COMMISSION_RATE{ 0.05 };
		  constexpr double MIN_COMMISSION_RATE{ 0.01 };
		  double commission{};
		  unsigned total_sales{};
		  std::cout << "Please enter total Sales in Rs:";
		  std::cin >> total_sales;
		  if (total_sales >= SALES_TARGET) {
			  commission = total_sales * MAX_COMMISSION_RATE;
		  }
		  else {
			  commission = total_sales * MIN_COMMISSION_RATE;
		  }
		  std::cout << "The Commission payable is Rs:"
			  << std::setprecision(2) << std::fixed
			  << commission << std::endl;
	  }*/

	  //Check math knowledge
	  //Conditional statement can have expression
	  //{
	  //    int i1n{ 5 };
	  //    int i2n{ 7 };
	  //    int userAnswer{};
	  //    std::cout << i1n << " * " << i2n << "= ? :";
	  //    std::cin >> userAnswer;
	  //    if ( (i1n* i2n) == userAnswer) {
	  //        std::cout << "Hola! You are Smart!\n";
	  //    }
	  //    else {
	  //        std::cout << "Go back to school!\n";
	  //    }
	  //}

	  //{
	  //    int d1num{  };
	  //   
	  //    std::cout << "Please enter a number :";
	  //    std::cin >> d1num;
	  //    std::cout << "What's the square root of " << d1num << " ? ";
	  //    double dUserAnswer{};
	  //    std::cin >> dUserAnswer;
	  //    if (sqrt(d1num) == dUserAnswer) {
	  //        std::cout << "Hola! You are Smart!\n";
	  //    }
	  //    else {
	  //        std::cout << "Go back to school!\n";
	  //    }
	  //}

	  /*{
		  int d1num{  };

		  std::cout << "Please enter a number :";
		  std::cin >> d1num;
		  std::cout << "What's the square root of " << d1num << " ? ";
		  double dUserAnswer{};
		  std::cin >> dUserAnswer;
		  double dResult = sqrt(d1num);
		  if (dResult == dUserAnswer) {
			  std::cout << "Hola! You are Smart!\n";
		  }
		  else {
			  std::cout << "Go back to school!\n";
		  }
	  }*/

	  //{
	  //	int d1num{  };
	  //	std::cout << "Please enter a number :";
	  //	std::cin >> d1num;
	  //	std::cout << "What's the square root of " << d1num << " ? ";
	  //	double dUserAnswer{};
	  //	std::cin >> dUserAnswer;

	  //	{
	  //		double dResult = sqrt(d1num);
	  //		if (dResult == dUserAnswer) {
	  //			std::cout << "Hola! You are Smart!\n";
	  //		}
	  //		else {
	  //			std::cout << "Go back to school!\n";
	  //		}
	  //	}
	  //	//  std::cout << "The result is " << dResult << std::endl;

	  //}

	{
		int d1num{  };
		std::cout << "Please enter a number :";
		std::cin >> d1num;
		std::cout << "What's the square root of " << d1num << " ? ";
		double dUserAnswer{};
		std::cin >> dUserAnswer;

		if (double dResult = sqrt(d1num); dResult == dUserAnswer) {
			std::cout << "Hola! You are Smart!\n";
			std::cout << "You got the right answer :" << dResult << std::endl;
		}
		else {
			std::cout << "Go back to school!\n";
			std::cout << "Correct answer was " << dResult << std::endl;
		}

		//std::cout << "The result is " << dResult << std::endl;

	}
	std::this_thread::sleep_for(std::chrono::seconds(4));
	return 0;
}