#pragma once
#include <string>
#include <stdexcept>
namespace my_lib {
	enum class Month : std::int8_t { jan = 1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };

	struct Day {
		int _day{ 19 };
		Day() = default;

		Day(float) = delete;
		Day(double) = delete;
		Day(char) = delete;

		explicit Day(int d) {
			if (is_day_valid(d)) {
				_day = d;
			}
			else {
				throw std::invalid_argument("The day is invalid! (Should be in the range of (1..30)\n");
			}
		}
		bool is_day_valid(int d) {
			return d >= 1 && d <= 30;
		}
	};


	struct Date
	{
		/*An initializer for member specified as part of the member declaration is called an in-class initializer.
		non-static data member initializers only available with �-std=c++11 and later*/
		Day day;
		Month month;
		int year;

		/*Default constructor ; Parameterized constructor : Initialize the date instance to given date*/
		explicit Date(Day d = Day{}, Month m = Month::apr, int y = 2000)
		{
			//do input validation
			if (is_year_valid(y)) {
				year = y;
				month = m;
				day = d;
			}
			else {
				throw std::invalid_argument("The date set is invalid!");
			}
		}
		/*Returns true if the date is valid otherwise returns false*/
		bool is_year_valid(int year);

		/*Prints the date (day,month,year) foramt*/
		std::string getDate();

		/*Takes integer as a argument.
		add argument as number of days
		Returns the new date*/
		Date add_days(int number_of_days);
	};


	struct User {
		int _id;
		float _score;
		User(int id = 5, float score = 77.7f) {
			_id = id;
			_score = score;
		}
	};

	struct UserImproved {
		int _id;
		float _score;
		explicit UserImproved(int id = 5, float score = 77.7f) {
			_id = id;
			_score = score;
		}
	};

}