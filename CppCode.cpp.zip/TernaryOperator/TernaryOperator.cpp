// TernaryOperator.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <chrono>

int main()
/*Ternary operator*/
{
    //int n1{};
    //int n2{};
    //int n3{};
    //int max{};
    //std::cout << "Please enter 3 integers : ";
    //std::cin >> n1 >> n2 >> n3;
    //
    //max = (n1 > n2) ? n1 : n2;
    //std::cout << "Largest amongst first 2 integers is " << max << std::endl;
    //

    int m1{};
    int m2{};
    int m3{};
    int per{};
    std::cout << "Please enter marks in 3 subject : ";
    std::cin >> m1 >> m2 >> m3;
    per = (m1 + m2 + m3) / 3;

    (per >= 35) ? (std::cout << "PASS\n") : (std::cout << "fail");
}
 



// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
