#pragma once
#include <string>
namespace my_lib {
	enum class Month : std::int8_t { jan = 1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };

	struct Date
	{
		/*An initializer for member specified as part of the member declaration is called an in-class initializer.
		non-static data member initializers only available with �-std=c++11 and later*/
		int day;
		Month month;
		int year;

		/*Default constructor ; Parameterized constructor : Initialize the date instance to given date*/
		Date(int d = 19, Month m = Month::apr, int y = 2000)
		{
			//do input validation
			if (is_date_valid(d, m, y)) {
				day = d;
				month = m;
				year = y;
			}
			else {
				throw std::invalid_argument("The date set is invalid!");
			}
		}
		/*Returns true if the date is valid otherwise returns false*/
		bool is_date_valid(int day, Month mon, int year);

		/*Prints the date (day,month,year) foramt*/
		std::string getDate();

		/*Takes integer as a argument.
		add argument as number of days
		Returns the new date*/
		Date add_days(int number_of_days);
	};
}