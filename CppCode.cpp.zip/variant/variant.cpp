// variant.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <variant>
#include <stdexcept>
#include <string>
#include <vector>

void variant_basic() {
	std::variant<int, float> v;
	std::variant<int, float> w;

	v = 12;                              //  v becomes 12
	int i = std::get<int>(v);            // std::get<int>(v) returns the value

	// assign the variant v the variant w
	w = std::get<int>(v);               // You can ask for the value of a variant by type           
	w = std::get<0>(v);                 // You can ask for the value of a variant by index  
	w = v;


	// The type must be unique and the index valid
	 // std::get<double>(v);             // ERROR
	 // std::get<3>(v);                  // ERROR

	try {
		// the variant w holds an int value. Therefore, raises std::bad_variant_access exception.
		std::get<float>(w);
	}
	catch (std::bad_variant_access& e) {
		std::cerr << e.what() << "\n";
	}

	using namespace std::string_literals;
	//constructor call or assignment call is unambiguous, a simple conversion takes place.
	std::variant<std::string, int> x("abcde"s);    // Construction call
	x = "def"s;                                  // Assignment
}


void check_member_type(std::variant<int, std::string, bool>& v) {
	std::cout << std::endl;
	std::cout << "does variant hold integer ?: " << std::holds_alternative<int>(v) << "\n";
	std::cout << "does variant hold string ? : " << std::holds_alternative<std::string>(v) << "\n";
	std::cout << "does variant hold bool ?   : " << std::holds_alternative<bool>(v) << "\n";
}

/*
	using integer = int;
	int x;
	integer y;
*/
void find_whats_stored() {

	using VariantType = std::variant<int, std::string, bool>;
	VariantType v{};
	std::cout << std::boolalpha;
	check_member_type(v);

	v = 7;

	check_member_type(v);

	v = std::string{ "Anil" };

	check_member_type(v);

	v = false;

	check_member_type(v);
}

/*total size of a std::variant is typically the size of the biggest alternative, plus the size of the index

std::variant uses the memory in a similar way to union: so it will take the max size of the underlying types.
But since we need something that will know what�s the currently active alternative, then we need to add some more space.
*/
void whats_the_size() {
	using VariantType = std::variant<int, std::string, bool>;

	std::cout << "VariantType: " << sizeof(VariantType) << " bytes\n";
	std::cout << "std::string: " << sizeof(std::string) << " bytes\n";
	std::cout << "std::size_t: " << sizeof(std::size_t) << " bytes\n"; // index

	std::cout << "sizeof string: " << sizeof(std::string) << "\n";

	std::cout << "sizeof variant<int, string>: " << sizeof(std::variant<int, std::string>) << "\n";

	std::cout << "sizeof variant<int, float>: " << sizeof(std::variant<int, float>) << "\n";

	std::cout << "sizeof double: " << sizeof(double) << "\n";
	//Alignment is not igonored
	std::cout << "sizeof variant<double,int>: " << sizeof(std::variant<double, int>) << "\n";
	std::cout << "Alignment of size_t index : " << alignof(size_t) << " bytes\n";
}

//"om" - > const char *
//"om"s - > std::string

void  variant_operations() {
	using namespace std::string_literals;
	std::variant<int, std::string, double> var{ "str"s };

	//index() allows us to know the index of the type that is active.
	std::cout << "Index of currently active member : " << var.index() << std::endl;  // 1

	var = 123;
	std::cout << "Index of currently active member : " << var.index() << std::endl;  // 0

	//emplace()   Creates a new contained value. constructs a value in the variant, in place
	var.emplace<2>(3.45);
	std::cout << "Index of currently active member : " << var.index() << std::endl;  // 0

	//valueless_by_exception() returns false if the variant holds a value.
	std::cout << "Variant doesn't hold the value : " << std::boolalpha << var.valueless_by_exception() << "\n";
	try {
		struct S {
			operator int() { throw 42; }
		};
		/*
		*  Emplace calls operator int to replace the value, but that throws.
		*  After that, the variant is in a wrong state, as we cannot recover.
		*/
		var.emplace<0>(S()); // v may be valueless
	}
	catch (...) {
		std::cout << "Variant doesn't hold the value : " << std::boolalpha << var.valueless_by_exception() << "\n";
	}

	var.emplace<1>("Hello"s);
	if (std::holds_alternative<std::string>(var)) {    // if var holds a string
		std::cout << "Current Value of variant : " << std::get<std::string>(var) << std::endl;	// "hello"
	}
}


enum class ErrorCode
{
	Ok,
	SystemError,
	IoError,
	NetworkError
};

/*effectively function returning different type of value*/
std::variant<std::string, ErrorCode> fetchNameFromNetwork(int i)
{
	switch (i) {
	case 0:
		return std::string("All is Well");
	case 1:
		return ErrorCode::SystemError;
	case 2:
		return ErrorCode::IoError;
	case 3:
		return ErrorCode::NetworkError;
	default:
		return std::string("Unknown Problem");
	}

}

void error_handling() {
	auto response = fetchNameFromNetwork(0);
	if (std::holds_alternative<std::string>(response)) {
		std::cout << std::get<std::string>(response) << "\n";
	}
	else {
		std::cout << "Error Code : " << static_cast<int>(std::get<ErrorCode>(response)) << "\n";
	}

	response = fetchNameFromNetwork(3);
	if (std::holds_alternative<std::string>(response)) {
		std::cout << std::get<std::string>(response) << "\n";
	}
	else {
		std::cout << "Error Code : " << static_cast<int>(std::get<ErrorCode>(response)) << "\n";
	}
}


//safe get, if the alternative is not active, it returns null pointer
// std::get_if Pointer to the value stored in the pointed-to variant or null pointer on error.
void alternative_to_get() {
	using namespace std::literals;

	std::variant<int, std::string, double> var{ "string_data"s };

	//Type-based non-throwing accessor
	if (auto pval = std::get_if<std::string>(&var)) {
		std::cout << "variant value: " << *pval << std::endl;
	}
	else {
		std::cout << "Doesn't contain String" << std::endl;
	}

	// Index-based non-throwing accessor:
	if (auto pval = std::get_if<1>(&var)) {
		std::cout << "variant value: " << *pval << std::endl;
	}
	else {
		std::cout << "index 1 doesn't " << std::endl;
	}
}

void monostate_demo() {
	struct X
	{
		X(int i) : i(i) {}
		int i;
	};

	struct Y
	{
		Y(float f) : f(f) {}
		float f;
	};

	// default initialization: (type has to has a default ctor)
	std::variant<int, float> intFloat;
	std::cout << intFloat.index() << ", value " << std::get<int>(intFloat) << "\n";

	//std::variant<X, Y> var; //Error : This is because X is not default-constructible.

	std::variant<std::monostate, X, Y> var;
	std::cout << "Default to monstate : " << var.index() << " \n";

	var.emplace<1>(X(12));
	std::cout << "Current Index : " << var.index() << ", X value " << std::get<X>(var).i << "\n";

	var.emplace<2>(Y(12.5f));
	std::cout << "Current Index : " << var.index() << ", Y value " << std::get<Y>(var).f << "\n";
}

#include <utility>
void in_place_demo() {
	// pass a value:
	std::variant<int, float, std::string> intFloatString1{ 10.5f };
	std::cout << intFloatString1.index() << ", value " << std::get<float>(intFloatString1) << "\n";


	// ambiguity :  double might convert to float or int, so the compiler cannot decide
	//std::variant<int, float, std::string> intFloatString{ 10.5 }; //Error

	// ambiguity resolved by in_place
	// std::in_place_index - used to specify which index you want to change / set.
	// Types are numerated from 0.
	std::variant<int, float, std::string> intFloatString2{ std::in_place_index<1>, 7.6 }; // double!
	std::cout << intFloatString2.index() << ", value " << std::get<float>(intFloatString2) << "\n";

	// in_place for complex types
	std::variant<std::vector<int>, std::string> vecStr{ std::in_place_index<0>, { 0, 1, 2, 3 } };
	std::cout << vecStr.index() << ", vector size " << std::get<std::vector<int>>(vecStr).size() << "\n";

	// ambiguity resolved by in_place
	//std::in_place_type - used to specify which type you want to change/set in the variant
	std::variant<int, float, std::string> intFloatString3{ std::in_place_type<float>, 7.6 }; // double!
	std::cout << intFloatString3.index() << ", value " << std::get<float>(intFloatString3) << "\n";

	std::variant<int, float, std::string> intFloatString4{ std::in_place_type<int>, 7.6 }; // double!
	std::cout << intFloatString4.index() << ", value " << std::get<int>(intFloatString4) << "\n";


}

/*
* When you use�union, you need to manage the internal state: call constructors or destructors.
 .But�std::variant�handles object lifetime as you expect.
  That means that if it�s about to change the currently stored type then a destructor
  of the underlying type is called

*/
void object_life_time() {
	std::variant<std::string, int> v1{ "Hello A Quite Long String" };
	// v allocates some memory for the string
	v1 = 10; // we call destructor for the string!
	// no memory leak

	class MyType
	{
	public:
		MyType() { std::cout << "MyType::MyType\n"; }
		~MyType() { std::cout << "MyType::~MyType\n"; }
	};

	class OtherType
	{
	public:
		OtherType() { std::cout << "OtherType::OtherType\n"; }
		OtherType(const OtherType&) {
			std::cout << "OtherType::OtherType(const OtherType&)\n";
		}
		~OtherType() { std::cout << "OtherType::~OtherType\n"; }
	};

	std::variant<MyType, OtherType> v2{};
	v2 = OtherType();

}


void variant_comparision() {
	/* Most-strict:
	   Only variants can equal each other, and they need to match both in the
	   sequence-of-alternatives (i.e. the type), the actual alternative (the index, really,
	   since you can have multiple identical-type alternatives) and in value.
	*/
	std::variant<int, float> v1{ 10 };
	std::variant<int, float> v2{ 10 };

	std::cout << "v1 == v2 : " << std::boolalpha << (v1 == v2) << "\n";

	v1.emplace<0>(10);
	v2.emplace<1>(10);
	std::cout << "v1 == v2 : " << std::boolalpha << (v1 == v2) << "\n";

	std::variant<int, float> v3{ 10 };
	std::variant<float, int > v4{ std::in_place_type<int>,10 };
	//std::cout << "v3 == v4 : " << std::boolalpha << (v3 == v4) << "\n";

	std::variant<int, float> v5{ 10 };
	std::variant< int, float, double> v6{ 10 };
	//std::cout << "v5 == v6 : " << std::boolalpha << (v5 == v6) << "\n";

}
int main()
{
	  variant_basic();
	  find_whats_stored();
	  whats_the_size();
	  variant_operations();
	  error_handling();
	  alternative_to_get();
	  monostate_demo();
	 in_place_demo();
	 object_life_time();
	 variant_comparision();

}

void conversion() {
	struct student {
		std::string name;
		int roll;
		explicit operator int() {
			return roll;
		}

	}s1{ "Raja",10 };

	student s2 = s1;
	int roll_no = static_cast<int>(s1);
	//  float f = static_cast<float>(s1);
	std::cout << roll_no;
	// std::string name = s1;
}