// iterationAssignment.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <iomanip>

using std::cout;
using std::cin;
using std::endl;


/*Tejas*/
//int main()
//{
//	int i{ 2 };
//	int count{ 0 };
//	cout << "Enter a positive integer  ";
//	int num;
//	cin >> num;
//	cout << "first " << num << " Even numbers are  " << endl;
//	for (; i >= 2; i += 2)
//	{
//		cout << i << endl;
//		count++;
//
//		if (count == num)
//		{
//			break;
//		}
//	}
//	return 0;
//}

/*
Accept an integer n, and print all even numbers less than n
*/
/*Appu*/
//#include<iostream>
//#include <iomanip>
//int main()
//{
//    std::cout << "Enter a number :" ;
//    int inum;
//    std::cin >> inum;
//    std::cout << "The Even Numbers less than " << inum << " are :\n";
//    for (int i{ 2 }; i < inum; i += 2)
//    {
//        std::cout << std::setw(10) << i << std::endl;
//      
//    }
//    return 0;
//}

/*
Accept an integer n, and print first n even numbers
*/

//int main() {
//	int ilimit{};
//	std::cout << "How many even numbers do you want to print ? ";
//	std::cin >> ilimit;
//	std::cout << "The first " << ilimit << " even numbers are as follows" <<endl;
//	for (int ieven{ 2 }; ieven <= (ilimit * 2); ieven += 2) {
//		std::cout << std::setw(10) << ieven << std::endl;
//	}
//	return 0;
//}

/* Print first n fibonacci numbers*/

//int main() {
//	int ifibo_numbers{};
//	std::cout << "How many fibonacci series numbers do you want ?";
//	std::cin >> ifibo_numbers;
//	long long ll_first{ 0 };
//	long long ll_second{ 1 };
//	long long fibo{};
//	for (int icounter{ 1 }; icounter <= ifibo_numbers; ++icounter) {
//		std::cout << fibo << ' ';
//		fibo = ll_first + ll_second;
//		ll_second = ll_first;
//		ll_first = fibo;
//	}
//	return 0;
//}
/* Accept integer n and display the first n rows from the following series
	1
	1 2
	1 2 3
	1 2 3 4
	when n == 4
*/

//int main() {
//	int itotal_rows{};
//	cout << "How many rows do you want to print ? ";
//	cin >> itotal_rows;
//
//	//Outer loop handles number of rows
//	for (int irow{ 1 }; irow <= itotal_rows; ++irow) {
//		//inner loop handles elements on each row
//		for (int icol{ 1 }; icol <= irow; ++icol) {
//			cout << icol << " ";
//		}
//		cout << endl;
//	}
//	return 0;
//}
//
//
/* Accept integer nand display the first n rows from the following series
4
4 3
4 3 2
4 3 2 1
when n == 4
*/

//int main() {
//	int itotal_rows{};
//	cout << "How many rows do you want to print ? ";
//	cin >> itotal_rows;
//
//	//Outer loop handles number of rows
//	for (int irow{ itotal_rows }; irow >= 1; --irow) {
//		//inner loop handles elements on each row
//		for (int icol{ itotal_rows }; icol >= irow; --icol) {
//			cout << icol << " ";
//		}
//		cout << endl;
//	}
//	return 0;
//}


/* Accept integer n and display the first n rows from the following series
	4 3 2 1
	4 3 2
	4 3
	4
	when n == 4
*/
//int main() {
//	int itotal_rows{};
//	cout << "How many rows do you want to print ? ";
//	cin >> itotal_rows;
//
//	//Outer loop handles number of rows
//	for (int irow{ 1 }; irow <= itotal_rows; ++irow) {
//		//inner loop handles elements on each row
//		for (int icol{ itotal_rows }; icol >= irow; --icol) {
//			cout << icol << " ";
//		}
//		cout <<  endl;
//	}
//	return 0;


	/* Accept integer n and display the first n rows from the following series
		 *
		 *  *
		 *  *  *
		 *  *  *   *
		when n == 4
	*/
//int main() {
//	int itotal_rows{};
//	cout << "How many rows do you want to print ? ";
//	cin >> itotal_rows;
//
//	//Outer loop handles number of rows
//	for (int irow{ 1 }; irow <= itotal_rows; ++irow) {
//		//inner loop handles elements on each row
//		for (int icol{ 1 }; icol <= irow; ++icol) {
//			cout << "*" << " ";
//		}
//		cout << endl;
//	}
//	return 0;
//}


/* Accept integer n and display the first n rows from the following series
		 *
	   *   *
	 *   *   *
   *   *   *   *
	when n == 4
*/
//int main() {
//	int itotal_rows{};
//	cout << "How many rows do you want to print ? ";
//	cin >> itotal_rows;
//
//	//Outer loop handles number of rows
//	for (int irow{ 1 }; irow <= itotal_rows; ++irow) {
//		for (int ispace{ 1 }; ispace <= (itotal_rows- irow); ++ispace) {
//			cout << " " ;
//		}
//		//inner loop handles elements on each row
//		for (int icol{ 1 }; icol <= irow; ++icol) {
//			cout << "* " ;
//		}
//		cout << endl;
//	}
//	return 0;
//}

/* Accept integer n and display the first n rows from the following series

		  *
		 ***
		*****
	   *******
*/
//int main()
//{
//	int i, j, n;
//	cout << "\n\n Display such a pattern like a pyramid containing odd number of asterisk in each row:\n";
//	cout << "-----------------------------------------------------------------------------------------\n";
//	cout << " Input number of rows: ";
//	cin >> n;
//	for (i = 0; i < n; i++)
//	{
//		for (j = 1; j <= n - i; j++)
//			cout << " ";
//		for (j = 1; j <= 2 * i - 1; j++)
//			cout << "*";
//		cout << endl;
//	}
//}
// 
//
/* Accept integer n and display the first n rows from the following series
         1
		 2 3
		 4 5 6
		 7 8 9 10
//*/
//int main(){
//	int i, j, rows, k = 1;
//	cout << "\n\n Display such a pattern like right angle triangle with number increased by 1:\n";
//	cout << "---------------------------------------------------------------------------------\n";
//	cout << " Input number of rows: ";
//	cin >> rows;
//	for (i = 1; i <= rows; i++)
//	{
//		for (j = 1; j <= i; j++)
//			cout << k++ << " ";
//		cout << endl;
//	}
//}

/*
		 1
		 0 1
		 1 0 1
		 0 1 0 1

*/
//
//int main()
//{
//	int i, j, n, p, q;
//	cout << "\n\n Print the Floyd's Triangle:\n";
//	cout << "--------------------------------\n";
//	cout << " Input number of rows: ";
//	cin >> n;
//	for (i = 1; i <= n; i++)
//	{
//		if (i % 2 == 0)
//		{
//			p = 1; q = 0;
//		}
//		else
//		{
//			p = 0; q = 1;
//		}
//		for (j = 1; j <= i; j++)
//			if (j % 2 == 0)
//				cout << p;
//			else
//				cout << q;
//		cout << endl;
//	}
//}

/*
			  *
			 * *
			* * *
		   * * * *
			* * *
			 * *
			  *
*/

//int main()
//{
//	int i, j, r;
//	cout << "\n\n Display the pattern like a diamond:\n";
//	cout << "----------------------------------------\n";
//	cout << " Input number of rows (half of the diamond): ";
//	cin >> r;
//	for (i = 0; i <= r; i++)
//	{
//		for (j = 1; j <= r - i; j++)
//			cout << " ";
//		for (j = 1; j <= 2 * i - 1; j++)
//			cout << "*";
//		cout << endl;
//	}
//	for (i = r - 1; i >= 1; i--)
//	{
//		for (j = 1; j <= r - i; j++)
//			cout << " ";
//		for (j = 1; j <= 2 * i - 1; j++)
//			cout << "*";
//		cout << endl;;
//	}
//}

/*

		i/p = E

		A B C D E D C B A
		A B C D   D C B A
		A B C       C B A
		A B           B A
		A               A


*/

//int main(){
//	int i, j;
//	char CH = 'E';
//	int space = 2;
//
//	for (i = 1; i <= 5; i++)
//	{
//		for (j = 'A'; j <= CH; j++)
//			cout << ((char)(j));
//
//		if (i == 1)
//			cout << "\b";
//
//		for (j = 1; j < space; j++)
//			cout << " ";
//
//
//		for (j = CH; j >= 'A'; j--)
//			cout << ((char)(j));
//
//		cout << endl;
//		CH--;
//		space++;
//	}
//	return 0;
//}