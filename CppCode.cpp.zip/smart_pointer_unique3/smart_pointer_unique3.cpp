// smart_pointer_unique3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <string>

class Resource {
	std::string name{ "Blank" };
public:


	Resource() {
		std::cout << name << " - Resource is created\n";
	}

	Resource(std::string _name) :name(_name) {
		std::cout << name << " - Resource is created\n";
	}

	~Resource() {
		std::cout << name << " - Resource is destroyed\n";
	}

	friend std::ostream& operator<<(std::ostream& os, const Resource& obj) {
		os << "Operating on Resource - " << obj.name << "\n";
		return os;
	}

};


void make_unique_demo() {

	//Using operator new
	{
		std::unique_ptr<Resource> up1{ new Resource };
		std::cout << *up1;
		std::unique_ptr<Resource> up2{ new Resource("Moon") };
		std::cout << *up2;
	}
	//using make_unique
	{
		std::unique_ptr<Resource> up1 = std::make_unique<Resource>();
		std::cout << *up1;
		std::unique_ptr<Resource> up2 = std::make_unique<Resource>("Sun");
		std::cout << *up2;

		auto up3 = std::make_unique<Resource>("Mars");
		std::cout << *up3;
	}
}

void unique_array_primitive() {
	//using operator new : Primitive type

	constexpr size_t size{ 5 };

	std::unique_ptr<int[]> upa1{ new int[size] }; //no initial values (grabage)

	// Access & manipulate the elements in array using unique_pointer
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i] << ", ";
		upa1[i] = i + 10;
	}
	std::cout << "\n";
	// Access  the elements in array using unique_pointer
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i] << ", ";
	}
	std::cout << "\n";


}

void unique_array_class() {
	constexpr size_t size{ 5 };

	//unique pointer to array of resource
	std::unique_ptr<Resource[]> upa1{};

	std::unique_ptr<Resource[]> upa2{ new Resource[size] };
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa2[i];
	}
	std::cout << "\n";

}

void make_unique_array_primitive() {
	constexpr size_t size{ 5 };
	//create uinque pointer holding array of integers
	//std::unique_ptr<int[]> upa1 = std::make_unique<int[]>(size); //default intitial values

	auto  upa1 = std::make_unique<int[]>(size);
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i] << ", ";
		upa1[i] = i + 10;
	}
	std::cout << "\n";
	// Access  the elements in array using unique_pointer
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i] << ", ";
	}
	std::cout << "\n";
}

void make_unique_array_class() {
	constexpr size_t size{ 5 };

	//unique pointer to array of resource
	//std::unique_ptr<Resource[]> upa = std::make_unique<Resource[]>(size);

	auto upa = std::make_unique<Resource[]>(size);

	std::cout << "\n";
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa[i];
	}
	std::cout << "\n";
}

void int_array_deleter(int* p) {
	std::cout << "deleting the integer array unsing function\n";
	delete[] p;
}

void custom_deleter_demo_primitive() {
	constexpr size_t size{ 5 };

	//using function object
	std::unique_ptr<int[], void(*) (int*) > upa1{ new int[size], int_array_deleter };
	std::cout << "\n";
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i] << ", ";
	}
	std::cout << "\n";

	//using lambda
	std::unique_ptr<int[], void(*)(int*)> upa2{ new int[size],[](int* p) { std::cout << "Lambda deleter \n "; delete[]p; } };
}


void resource_array_deleter(Resource* ptr) {
	std::cout << "Peforming the cleanup before the resource is destroyed\n";
	delete[] ptr;
}

void custom_deleter_demo_class() {
	constexpr size_t size{ 5 };

	//using function object
	std::unique_ptr<Resource[], void(*) (Resource*) > upa1{ new Resource[size], resource_array_deleter };
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa1[i];
	}
	std::cout << "\n";

	//using Lambda
	std::unique_ptr<Resource[], void(*) (Resource*) > upa2{ new Resource[size],
															[](Resource* p) {std::cout << "Lambda doing clean up\n";
																			 delete[] p; } };
	for (size_t i{ 0 }; i < size; ++i) {
		std::cout << upa2[i];
	}
	std::cout << "\n";
}


int main()
{
	 make_unique_demo();
	 unique_array_primitive();
	 unique_array_class();
	 make_unique_array_primitive();
	 make_unique_array_class();
	 custom_deleter_demo_primitive();
	 custom_deleter_demo_class();
}