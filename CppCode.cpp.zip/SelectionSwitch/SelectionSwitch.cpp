// SelectionSwitch.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using std::cout;
using std::cin;
using std::cerr;
using std::endl;

/*
* Accept a single digit number and display it in words
*/

//int main()
//{
//    cout << "Please enter a single digit integer :";
//    int inum{};
//    cin >> inum;
//    //Not recommended for judt one or two conditions
//    switch ((inum / 10 )) {
//    case 0:
//        cout << "It's  a singles digit number" << endl;
//    default:
//        cout << "It's not a single digit number" << endl;
//    }
//    //better alternative construct
//     if (inum % 10 == 0) {
//        cout << "it's a singles digit number" << endl;
//    }
//    else {
//        cout << "it's not a singles digit number" << endl;
//
//    }

   /* if (inum % 10 == inum) {
        cout << "it's a singles digit number" << endl;
    }
    else {
        cout << "it's not a singles digit number" << endl;

    }*/
    /*
    * Accept a number check whether it is single digit number
     */
#include <cmath>
/*
* fabs
* labs
* abs
* llabs
*/
/*
* Accept the single digit number and print it in words
*/

     
//int main() {
//    cout << "Please enter a single digit integer :";
//    int inum{};
//    cin >> inum;
//    //checking wheather the number is single digit
//    if (inum / 10 == 0) {
//        //print the number in words
//        cout << "Original Number :" << inum << "Absolute Value :" << labs(inum) << endl;
//        switch (labs(inum))
//        {
//        case 0:
//            cout << "The number is ZERO" << endl;
//            break;
//        case 1:
//            cout << "The number is ONE" << endl;
//            break; 
//        case 2:
//             cout << "The number is TWO" << endl;
//             break; 
//        case 3:
//             cout << "The number is THREE" << endl;
//             break;
//        case 4:
//            cout << "The number is FOUR" << endl;
//            break;
//        case 5:
//            cout << "The number is FIVE" << endl;
//            break;
//        case 6:
//            cout << "The number is SIX" << endl;
//            break;
//        case 7:
//            cout << "The number is SEVENTH" << endl;
//            break;
//        case 8:
//            cout << "The number is EIGTH" << endl;
//            break;
//        case 9:
//            cout << "The number is NINE" << endl;
//            break;
//        }
//    }
/*
* Acept the month and display the sesaon
*/
//int main(void)
//{
//    int month;
//
//    /* Read in a month value */
//    cout << "Enter month (1-12): ";
//    cin >> month;
//
//    /* Tell what season it falls into */
//    switch (month)
//    {
//    case 12:
//        [[fallthrough]]
//    case 1:
//        [[fallthrough]]
//
//    case 2:
//        cout << "month is a winter month\n";
//        break;
//    case 3:
//    case 4:
//    case 5:
//        cout << "month is a Summer month\n";
//        break;
//    case 6:
//    case 7:
//    case 8:
//    case 9:
//        cout << "month is a Rain month\n";
//        break;
//    case 10:
//    case 11:
//        cout << "month is a Spring month\n";
//        break;
//        
//    default:
//        cerr << "month number you have given is incorrect";
//    }
//

//int main(){
//    int iphy{};
//    int ichem{};
//    int imath{};
//    int iper{};
//    cout << "Please enter your markes in physics :";
//    cin >> iphy;
//    cout << "Please enter your markes in Chemistry :";
//    cin >> ichem;
//    cout << "Please enter your markes in Mathemetics :";
//    cin >> imath
//    constexpr int NUMBER_OF_SUBJECTS{ 3 };
//    iper = (iphy + imath + ichem) / NUMBER_OF_SUBJECTS;
//    switch (iper) {
//        case 0...{
//            cout << "Fail" << endl;
//        }
//    }

int main()
{
    char alphabet;
    cout << "Please enter an alphabet :";
    cin >> alphabet;
    //switch (char upperAlpha = toupper(alphabet); isalpha(upperAlpha) ? true : false);
    switch (char upperAlpha = toupper(alphabet); isalpha(upperAlpha)) {
    case 'A':
    case 'E':
    case 'I':
    case 'O':
    case 'U':
        cout << "'" << alphabet << "'is a vowel" endl;
        break;
    default:
        cout << "'" << alphabet << "'is a Consonant" endl;

    }
    else {
    cout << "'" << alphabet << "is NOT a alphabet" endl;

    }
    return 0;
}
 