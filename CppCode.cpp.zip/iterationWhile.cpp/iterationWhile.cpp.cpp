// iterationWhile.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <cmath>
using std::cout;
using std::endl;
using std::cin;

/*Accept name of a Student and display it 5 times*/
//int main()
//{
//    std::string name;
//    cout << "Please enter your name :";
//    cin >> name;
//    
//    constexpr int LIMIT = 5;
//    int counter = 1;
//    while (counter <= LIMIT) {
//        cout << "Hello, " << name << endl;
//        counter = counter + 1;
//    }
//    return 0;
//}

/*Print factors of a given integer : */
// int main() {
//	int i1n{};
//	cout << "Please enter a +ve integer : ";
//	cin >> i1n;
//	int icounter{1};
//	while (icounter <= i1n) {
//		if (i1n % icounter == 0) {
//			cout << icounter << " is factor of " << i1n << endl;
//		}
//		icounter = icounter + 1;
//	}
//	return 0;
//}

 /*Alternative*/

//int main() {
//	int inumber{};
//	cout << "Please enter a +ve integer : ";
//	cin >> inumber;
//	int icounter{ 1 };
//	while (icounter <= (inumber/2)) {
//		if (inumber % icounter == 0) {
//			cout << icounter << " is factor of " << inumber << endl;
//		}
//		icounter = icounter + 1;
//	}
//	cout << inumber << " is factor of " << inumber << endl;
//	return 0;
//}
//

/* check if the give integer is Prime*/
//int main() {
//	int inumber{};
//	cout << "Please enter a +ve integer : ";
//	cin >> inumber;
//	int icounter{ 2 };
//	int ifactor_count{};
//	int iteration_counter{ 1 };
//	while (icounter <= (inumber / 2)) {
//		if (inumber % icounter == 0) {
//			cout << icounter << " is factor of " << inumber << endl;
//			ifactor_count = ifactor_count + 1;
//		}
//		icounter = icounter + 1;
//		iteration_counter++;
//	}
//	if (ifactor_count == 0) {
//		cout << inumber << " is Prime" << endl;
//	}
//	else {
//		cout << inumber << " is Not Prime" << endl;
//	}
//	cout << "Number of passes required to get the answer :" << iteration_counter << endl;
//	return 0;
//}
// 

/*alternative - 2*/
//int main() {
//	int inumber{};
//	cout << "Please enter a +ve integer : ";
//	cin >> inumber;
//	int icounter{ 2 };
//	bool foundFactor = false;
//	while (icounter <= (inumber / 2)) {
//		if (inumber % icounter == 0) {
//			foundFactor = true;
//			break; //terminate the loop
//		}
//		icounter = icounter + 1;
//	}
//	if (foundFactor == false) {
//		cout << inumber << " is Prime" << endl;
//	}
//	else {
//		cout << inumber << " is Not Prime" << endl;
//	}
//	return 0;
//}

//alternative - 3
int main() {
	int inumber{};
	cout << "Please enter a +ve integer : ";
	cin >> inumber;
	int icounter{ 2 };
	bool foundFactor = false;
	int iteration_counter{ 1 };
	while (icounter <= sqrt(inumber)) {
		if (inumber % icounter == 0) {
			foundFactor = true;
			break; //terminate the loop
		}
		icounter = icounter + 1;
		iteration_counter++;
	}
	if (foundFactor == false) {
		cout << inumber << " is Prime" << endl;
	}
	else {
		cout << inumber << " is Not Prime" << endl;
	}
	cout << "Number of passes required to get the answer :" << iteration_counter << endl;
	return 0;
}