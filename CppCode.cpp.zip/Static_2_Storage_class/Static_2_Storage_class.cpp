// Static_2_Storage_class.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Static Global variable

#include <iostream>
#include "first.h"


int main()
{
	first_fun();
	std::cout << "Inside MainApp.cpp :  e_var : " << e_var << std::endl;
	//std::cout << "Inside First.cpp : first_fun : s_var : " << s_var << std::endl;
	//std::cout << "Inside First.cpp : first_fun : grade  : " << grade << std::endl;
	second_fun();
	return 0;
}