#pragma once
// Header containing declaration
/*
Declaration is only an announcement of existance of varaible or a function
No memory is allocatied when a vaiable is declared
*/
extern int e_var; //declare the existance of the variable
extern void first_fun();
extern void second_fun();
/*No use of decalaring static global variable*/
//extern int s_var;
//extern char grade;