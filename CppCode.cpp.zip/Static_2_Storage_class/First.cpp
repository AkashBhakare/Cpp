#include <iostream>
#include "first.h"

/*
Static Global variables :
	Visibilty:	Visible(accessible) only inside the code block where they have been defined
	Lifetime :	Througout the execution of the program
				It is created when the program execution beginsand is destroyed only
				when the program exectuion gets over
	Linkage :	Internal
*/

/*Non static Global Variable has external linkage*/
int e_var{ 99 };

/*static Global Variable has internal linkage*/
static int s_var{ 77 };

/*Global Variable having internal linkage*/
namespace {
	char grade{ 'A' };
}

/*definition of function */
void first_fun() {
	std::cout << "Inside First.cpp : first_fun : e_var : " << e_var << std::endl;
	std::cout << "Inside First.cpp : first_fun : s_var : " << s_var << std::endl;
	std::cout << "Inside First.cpp : first_fun : grade  : " << grade << std::endl;
	return;
}

void second_fun() {
	std::cout << "Inside First.cpp : second_fun : e_var : " << e_var << std::endl;
	std::cout << "Inside First.cpp : second_fun : s_var : " << s_var << std::endl;
	std::cout << "Inside First.cpp : second_fun : grade  : " << grade << std::endl;
	return;
}