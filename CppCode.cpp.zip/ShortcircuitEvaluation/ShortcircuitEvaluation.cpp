// ShortcircuitEvaluation.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <chrono>
#include <thread>

bool iskid(int age, const int& MIN_AGE)
{
	return age <= MIN_AGE;
}

bool isSenior(int age, const int& MAX_AGE)
{
	return age >= MAX_AGE;
}
int main()
{
	int age{};
	constexpr int MIN_AGE{ 12 };
	constexpr int MAX_AGE{ 60 };
	std::cout << "Please enter your age in year : ";
	std::cin >> age;

	if (iskid(age)) {
		std::cout << "you are eligible for concession during travel\n";
	}
	else {
		std::cout << "you are not eligible for concession during travel\n";
	}

}