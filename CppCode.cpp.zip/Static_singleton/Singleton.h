#pragma once
#include<string>
#include <vector>

namespace old_lib {
	class Singleton
	{
	private:
		std::string name;
		std::vector<int> data;
	public:
		Singleton();
		std::string get_name();
		size_t get_data_size();
	};

}

namespace new_lib {
	class Singleton
	{
	private:
		std::string name;
		std::vector<int> data;
		Singleton(); //private constructor
	public:
		static Singleton& getInstance();
		Singleton(const Singleton&) = delete;
		Singleton& operator=(const Singleton&) = delete;
		std::string get_name();
		size_t get_data_size();
	};

}