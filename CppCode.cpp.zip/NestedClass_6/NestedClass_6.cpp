// NestedClass_6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <set>
#include <vector>
#include<queue>
#include "Queue.h"
int main()
{

    mylib::Queue que{ 6 };
    try {
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Aakash");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Neha");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Appu");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Rushi");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Aman");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        que.push("Sarthak");
        std::cout << "Capacity : " << que.max_capacity() << std::endl;
        std::cout << "Size     : " << que.size() << std::endl;
        //     que.push("Tejas");


        std::cout << "Element at front : " << que.peek() << std::endl;
        std::cout << "Element at front : " << que.peek() << std::endl;
        std::cout << "Element at front : " << que.peek() << std::endl;
        que.pop();
        std::cout << "Element at front : " << que.peek() << std::endl;
        que.pop();
        std::cout << "Element at front : " << que.peek() << std::endl;
        que.pop();
        std::cout << "Element at front : " << que.peek() << std::endl;
        std::cout << "Accessing all the elements from the queue using iterator : \n";
        mylib::Queue::Iterator itr{};
        itr = que.begin();
        while (itr != que.end()) {
            std::cout << *itr << "\n";
            itr++;
        }

        std::cout << "Element at front : " << que.peek() << std::endl;
        std::set<int>::iterator iter;
        std::set<int> s1{ 12,13,14,15,16 };
        std::set<int> s2{ 1,3,4,5,6 };
        std::vector<int> v{ 12,13,14,15,16 };
        iter = s1.begin();
        while (iter != s1.end()) {
            std::cout << *iter << "\n";
            iter++;
        }
        iter = s2.begin();
        while (iter != s2.end()) {
            std::cout << *iter << "\n";
            iter++;
        }

    }
    catch (std::overflow_error& e) {
        std::cerr << e.what() << std::endl;
    }
    catch (std::underflow_error& e) {
        std::cerr << e.what() << std::endl;
    }
    catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }
}