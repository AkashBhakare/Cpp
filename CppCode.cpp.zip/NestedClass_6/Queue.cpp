#include "Queue.h"
#include <stdexcept>
mylib::Queue::Queue(size_t max_capacity)
{
	/*Allocate one extra block for indicating the end of queue*/
	queue.resize(max_capacity + 1);
	resetQueue();
}

void mylib::Queue::push(std::string data)
{
	if (isFull()) {
		throw std::overflow_error("The Queue is Full\n");
	}
	rear = rear + 1;
	queue[rear] = std::move("Mr/Miss : " + data);
}

bool mylib::Queue::pop()
{
	if (isEmpty()) {
		throw std::underflow_error("The queue is empty\n");
	}

	front = front + 1;
	if (rear == front) {
		resetQueue();
	}
	return true;
}

std::string mylib::Queue::peek()
{
	if (isEmpty()) {
		throw std::underflow_error("The queue is empty\n");
	}

	return queue.at(front + 1);
}

void mylib::Queue::resetQueue()
{
	rear = -1;
	front = -1;
}

bool mylib::Queue::isEmpty()
{
	return rear == -1 and front == -1;
}

bool mylib::Queue::isFull()
{
	return rear == max_capacity() - 1;
}

size_t mylib::Queue::size()
{
	return rear + 1;
}

size_t mylib::Queue::max_capacity()
{
	return queue.capacity() - 1;
}

mylib::Queue::Iterator::Iterator()
{
	iter = nullptr;
}



mylib::Queue::Iterator::Iterator(std::string* ptr) :iter(ptr)
{
}


mylib::Queue::Iterator mylib::Queue::begin()
{
	//std::vector<std::string,std::allocator<std::string>>* ptr = &queue[0];
	/*std::string* ptr = &queue[0];
	return Iterator(ptr);*/
	return Iterator(&queue[0]);

}

mylib::Queue::Iterator mylib::Queue::end()
{
	/*Returns the address of the string beyond the last string in the queue*/
	return Iterator(&queue[rear + 1]);
}


std::string mylib::Queue::Iterator::operator*()
{
	return *iter;
}

std::string* mylib::Queue::Iterator::operator++()
{
	iter = iter + 1;
	return iter;
}

std::string* mylib::Queue::Iterator::operator++(int)
{
	std::string* temp = iter;
	iter = iter + 1;
	return temp;
}


bool mylib::Queue::Iterator::operator!=(Iterator otherIter)
{
	return iter != otherIter.iter;
}

