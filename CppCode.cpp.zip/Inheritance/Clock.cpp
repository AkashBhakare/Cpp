#include "Multi_Inherit.h"
#include <iostream>
namespace mylib {
	mylib::Time::Time()
	{
		std::cout << "Time Ctor called\n";
	}

	mylib::Time::~Time()
	{
		std::cout << "Time Dtor called\n";
	}

	mylib::Calender::Calender()
	{
		std::cout << "Calender Ctor called\n";
	}

	mylib::Calender::~Calender()
	{
		std::cout << "Calender Dtor called\n";
	}

	mylib::Clock::Clock()
	{
		std::cout << "Clock Destroyed\n";
	}

	mylib::Clock::~Clock()
	{
		std::cout << "Clock Created\n";
	}


}
