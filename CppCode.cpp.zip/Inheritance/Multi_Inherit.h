#pragma once
namespace mylib {

	class Time
	{
	private:
		int hour{};
		int minute{};
		int second{};
	public:
		Time();
		~Time();
		/*
		* Yet to be implemented
		*/

	};

	class Calender {
	private:
		int day{};
		int month{};
		int year{};
	public:
		Calender();
		~Calender();
	};

	class Clock : public Time, public Calender {
	public:
		Clock();
		~Clock();
	};
};

