// Inheritance_7.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Basic of Multiple Inheritance
//Order of invoking Ctor and Dtor

#include <iostream>
#include "Multi_Inherit.h"

int main()
{
    {
        mylib::Time time{};
        std::cout << "Size of time class object : " << sizeof(mylib::Time) << "bytes\n";
        
        mylib::Calender Calender{};
        std::cout << "Size of Calender class object : " << sizeof(mylib::Calender) << "bytes\n";

    }

        /*Order of calling constructors for derived class object is from Base to Derived.
        when we have multiple base classes the order classes the order of invoking constructors of base class
        is same as order of inheritance

        Order of calling destructors for derived class object is from Base to Derived.to Base
        when we have multiple base classes the order classes the order of invoking destructors of base class
        is the reverse of order of inheritance*/

    {
        mylib::Clock aclock{};
        std::cout << "Size of Clock class object : " << sizeof(mylib::Clock) << "bytes\n";


    }


}
