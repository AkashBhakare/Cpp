// Inheritance_3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

class Vehicle {
private:
    float price;
    int year_of_manufacture;
};

/*
* For Car class Vehicle is direct base class or Parent Class
*/
class Car : public Vehicle {
private:
    int chasis_number;
    int engine_number;
};

/*
* For RacingCar; Car is Direct base class whereas Vehicle is indirect Base class
*/
class RacingCar : public Car {
    int max_intro_booster;

};


int main()
{
    std::cout << "Size of Vehicle   : " << sizeof(Vehicle) << " bytes \n";
    std::cout << "Size of Car       : " << sizeof(Car) << " bytes \n";
    std::cout << "Size of RacingCar : " << sizeof(RacingCar) << " bytes \n";
    return 0;
}