// PointerBasics.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
#include <cinttypes>

void pointer_intro();
void pointer_rules();

int main()
{
    //  pointer_intro();
    pointer_rules();
    return EXIT_SUCCESS;
}

void pointer_intro()
{
    /*Variable names are identifiers*/
    int i1n{ 10 };
    /*Accessed the value of the variable directly using variable name*/
    std::cout << "Values of i1n : " << i1n << "\n";
    /*Accessed the Address of the variable using & operator*/
    std::cout << "Address of i1n: " << &i1n << "\n";
    int i2n{ i1n };
    std::cout << "Values of i2n : " << i2n << "\n";
    std::cout << "Address of i2n: " << &i2n << "\n";
    i1n = 99;
    std::cout << "Values of i1n : " << i1n << "\n";
    std::cout << "Values of i2n : " << i2n << "\n";
    /*
    cannot convert from 'int *' to 'int'
    i2n = &i1n;
    */

    /*Pointer to integer pointing nowhere*/
    int* i_ptr1{ nullptr }; //currently its not pointing to any integer
    std::cout << "Values of i_ptr1 : " << i_ptr1 << "\n";

    /*Assigned address of integer variable  to pointer to integer*/
    i_ptr1 = &i1n;
    std::cout << "Value of i_ptr1 i.e address of i1n : " << i_ptr1 << "\n";

    /*Dereferencing a pointer to fetch the value at the address stored in the pointer
    Indirectly accessing the Valueof the varaible whose address the pointer stores    */
    std::cout << "Value at the address stored in i_ptr1 : " << *i_ptr1 << "\n";

    /*Manuplating the value stored at the address stored in the pointer variable*/
    *i_ptr1 = 555;
    std::cout << "Value at the address stored in i_ptr1 : " << *i_ptr1 << "\n";
    std::cout << "Values of i1n : " << i1n << "\n";
    return;
}

void pointer_rules() {
    int i1n{ 10 };
    int* i_ptr1{ &i1n };

    std::cout << "Values of i1n (directly) : " << i1n << "\n";
    std::cout << "Value of i_ptr1 i.e address of i1n : " << i_ptr1 << "\n";
    std::cout << "Value at the address stored in i_ptr1 (indireclty) : " << *i_ptr1 << "\n";

    /* Multiple pointers can point ot same memory location i.e.
       Multiple pointers can store address of same variable*/
    int* i_ptr2{ nullptr };
    i_ptr2 = &i1n;
    std::cout << "Value of i_ptr2 i.e address of i1n : " << i_ptr2 << "\n";
    std::cout << "Value at the address stored in i_ptr2 (indireclty) : " << *i_ptr2 << "\n";


    /*We can assign one pointer to another pointer provided both are of same type*/
    int* i_ptr3{ nullptr };
    i_ptr3 = i_ptr2;     //Pointer assignment is possible
    std::cout << "Value of i_ptr3 i.e address of i1n : " << i_ptr3 << "\n";
    std::cout << "Value at the address stored in i_ptr3 (indireclty) : " << *i_ptr3 << "\n";

    char c_var = 'A';
    std::cout << "Address of c_var : " << &c_var << std::endl; //incorrect way
    std::cout << "Address of c_var : " << std::showbase << std::hex << std::uppercase
        << reinterpret_cast<uint64_t>(&c_var) << std::endl;  //correct way

    std::cout << "Value of c_var   : " << c_var << std::endl;
    std::cout << "Address of i1n : " << std::showbase << std::hex << std::uppercase
        << reinterpret_cast<uint64_t>(&i1n) << std::endl;
    /*
    Reason: cannot convert from 'char *' to 'int *'
    int* i_ptr4{ &c_var };
    */
    char* c_ptr{ &c_var };
    std::cout << "Value of c_var using pointer  : " << *c_ptr << std::endl;
    std::cout << "Address of c_var using pointer: " << std::showbase << std::hex << std::uppercase
        << reinterpret_cast<uint64_t>(c_ptr) << std::endl;

    std::cout << std::noshowbase;
    /*All pointers are of same size but they point to blocks of different size*/
    std::cout << "Size of Pointer to integer   :" << sizeof(i_ptr1) << " bytes" << std::endl;
    std::cout << "Size of Pointer to Character :" << sizeof(c_ptr) << " bytes" << std::endl;
    std::cout << "Size of Pointer to Float     :" << sizeof(float*) << " bytes" << std::endl;

    /* cannot convert from 'char *' to 'int *'
    i_ptr1 = c_ptr;
    //One pointer can be assigned to another pointer provided both of them are pointing
     to varaible of same type
    */

}