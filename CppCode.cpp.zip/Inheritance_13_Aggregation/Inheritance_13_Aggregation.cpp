// Inheritance_13_Aggregation.cpp :
//Aggregation : The componants can outlive the agregate
//Weak association
//No exclusive ownership
//The componant can be a part of multiple aggregate
//Aggregate is not responsible for construction of componanats

#include <iostream>
#include "song.h"
#include "playlist.h"
using namespace std::literals;

int main()
{
	mylib::Song s1("My Love", "Sonu Nigum", 5.3f);
	std::cout << s1 << '\n';

	mylib::Song s2("Kora Kakaj", "Kishor Kumar", 4.4f);
	std::cout << s2 << '\n';
	std::cout << "playlist\n";
	mylib::PlayList list1("Travel_list"s, "Romantic");
	list1.add_song(s1);
	list1.add_song(s2);
	list1.print_playlist();
	std::cout << "Number of song in list1 : " << list1.get_song_count() << '\n';
	list1.remove_song("Kora Kakaj");
	list1::count << "Number of songs list1 : " << list1.get_song_count() << '\n';

}
