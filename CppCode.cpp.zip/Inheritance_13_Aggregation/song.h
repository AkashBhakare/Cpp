#pragma once
#include <string>
namespace mylib {
	class Song
	{
	public:
		Song(std::string title, std::string singer, float length);
		friend std::ostream& operator  << (std::ostream& out, const Song&);
	private:
		std::string title;
		std::string singer;
		float length;
	};

	std::ostream& operator << (std::ostream& out, const Song&);
}