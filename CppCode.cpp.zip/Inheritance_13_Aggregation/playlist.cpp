#include "playlist.h"
#include <iostream>
#include <algorithm>

mylib::PlayList::PlayList(std::string name, std::string genre)
{
	this->list_name = name;
	this->genre = genre;
}

std::string mylib::PlayList::get_genre() const
{
	return this->genre;
}
size_t string mylib::PlayList::get_song_count() const
{
	return songs.size();
}
void mylib::PlayList::print_playlist() const
{
	std::cout << "PlayList Name : " << list_name << "\nGenre : " << genre << '\n';
	for (auto song : songs)
		std::cout << song << '\n';
	std::cout << '\n';
}

void mylib::PlayList::add_song(Song & song)
{
	songs.push_back(song);
 
}
void mulib::PlayList::remove_song(std::string title)
{
	songs.erase(std::remove_if(songs.begin(), song.end(), [title](auto song) {return song->get_title() == title; }));
}