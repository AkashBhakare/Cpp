#include <iostream>
#include "song.h"

mylib::Song::Song(std::string title, std::string singer, float length)
{
	this->title = title;
	this->singer = singer;
	this->length = length;
}

std::ostream& mylib::operator<<(std::ostream& out, const Song& song)
{
	out << "Title : " << song.title << "\nSinger : " << song.singer << "\nSong Length : " << song.length << "min\n";
	return out;
}