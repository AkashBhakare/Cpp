#pragma once
#include <string>
#include <Vector>
#include <memory>
#include "song.h"

namespace mylib {
	class Playlist
	{
	public:
		PlayList(std::string name, std::string genre);
		std::string get_genre()const;
		size_t get_song_count()const;
		void print_playlist()const;
		void add_song(Song&);
		void remove_song(std::string title);
	private:
		std::string list_name;
		std::string genre;
		std::vector<Song> songs;
 	};
}