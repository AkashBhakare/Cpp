// Need_for_Exception.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
int main()
{
	int num1;
	int num2;
	int result;
	std::cout << "Please Enter the first integer:";
	std::cin >> num1;
	std::cout << "Please Enter the second integer:";
	std::cin >> num2;
	result = num1 / num2;
	std::cout << num1 << " / " << num2 << " = " << result << std::endl;
	return EXIT_SUCCESS;
}