﻿// Literal.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <complex>
#include <iomanip>
#include <string>   
#include <chrono>
using namespace std;
void integer_numerals();
void availability();
int divide(int a, int b);
float divide(float a, float b);
void ambiguity();
void accuracy();
void nonDecimalNumbers();

int main()
{
    //integer_numerals();
    //availability();

    //ambiguity();

    //accuracy();
    nonDecimalNumbers();

}

void integer_numerals() {
    //Literals  can be written by adding a suffix
    int a = 2;
    signed int max = 2;
    signed min = -2;

    unsigned int roll = 2u;
    unsigned class_no = 2U;

    long int c = 2L;
    signed long int b = -2L;

    unsigned long int d = 2ul;
    double e = 2.0;
    float f = 2.0F;
    float discount = 0.02f;
    long double g = 2.0L;
    /*
    In most cases, it is not necessary to declare the type of
    literals explicitly since the implicit conversion between
    built-in numeric types usually sets the values at the
    programmer�s expectation.
    */
}

void availability()
{
    /*The standard library provides a type for complex numbers
    where the type for the real and imaginary parts can be
    parameterized by the user
    */
    std::complex <float> z(1.3f, 2.4f);
    std::complex <float> z2;
    //z2 = 2 * z;     // Error: no int * complex <float >
    //z2 = 2.0 * z;   // Error: no double * complex <float >
    z2 = 2.0f * z;  // Okay: float * complex <float >
    /*
    Unfortunately, operations are only provided between the
    type itself and the underlying real type
    (and arguments are not converted here).
    As a consequence, we cannot multiply z with an int or double
    but with float:
    */
}

double divide(double a, double b) {
    return a / b;
}

float divide(float a, float b) {
    return std::floor(a / b);
}

void ambiguity() {
    //std::cout << divide(10.0, 5.0F) << endl;
    cout << divide(10.0F, 5.0F) << endl;
    cout << divide(10.0, 5.0) << endl;
}

void accuracy() {
    /*
    The accuracy issue comes up when we work with long double.
    Since the nonqualified literal is a double, we might lose
    digits before we assign it to a long double variable:
    */

    long double a = 0.3333333333333333333; // may lose digits
    cout << std::setprecision(19) << a << endl;
    long double b = 0.3333333333333333333L; // accurate
    cout << std::setprecision(19) << b << endl;
}

void nonDecimalNumbers() {
    /*
    Integer literals starting with a zero are interpreted
    as octal numbers
    */
    int o1 = 042; // int o1= 34;
    cout << o1 << endl;

    //int o2 = 084; // Error! No 8 or 9 in octals!
    /*
    Hexadecimal literals can be written by prefixing them
    with 0x or 0X:
    */
    int h1 = 0x42; // int h1= 66;
    cout << "h1 : " << h1 << endl;
    int h2 = 0xfa; // int h2= 250;
    cout << "h2 : " << h2 << endl;
    /*
    C++14 introduces binary literals which are prefixed by 0b or 0B:
    */
    int b1 = 0b11111010; // int b1= 250;
    cout << "b1 : " << b1 << endl;
    /*
    To improve readability of long literals,
    C++14 allows us to separate the digits with  apostrophes :
    */
    long long credit_card = 546'687'616'861'129LL;
    cout << "Credit card : " << credit_card << endl;
    unsigned long ulx = 0x139'ae3b'aul;
    cout << "in hex : " << ulx << endl;
    int b = 0b101'1001'0011'1010'1101'1010'0001;
    cout << "Binary : " << b << endl;
    const long double pi = 3.141'592'653'589'793'238'462L;
    cout << "pi " << pi << endl;

    //Use literal suffixes where clarification is needed
    auto hello = "Hello!"s; // a std::string
    auto world = "world";   // a C-style string
    auto interval1 = 100ms;  // using <chrono>
    //std::cout << interval1 << std::endl;
    auto interval2 = 100s;
    auto interval3 = 100h;
    auto interval4 = 100min;

}