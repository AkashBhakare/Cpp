﻿// Unicode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cwchar>
#include <thread>
#include <chrono>

int main()
{
    wchar_t wch{ L'₹' };//{ L'\x0438' };
    std::wcout << wch << std::endl;
    wch = L'\x20B9';
    std::wcout << wch;
    char32_t cyr{ U'₽' };
    char16_t ch16{};

    std::this_thread::sleep_for(std::chrono::seconds(30));



}

